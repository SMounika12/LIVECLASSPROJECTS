package BasicConcepts;

public class DataTypesExample2 {
	public static void main(String[] args) {
		int num1, num2;//declaration of variables
		num1=78;
		num2=89;
		int sum=num1+num2;
		System.out.println("Total="+sum);
		
	}
}
