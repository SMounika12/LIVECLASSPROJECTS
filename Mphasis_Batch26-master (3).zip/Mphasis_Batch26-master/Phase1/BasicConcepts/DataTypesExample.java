package BasicConcepts;
//import java.lang.*;

public class DataTypesExample {

	public static void main(String[] args) {
		
		System.out.println("Hello All");
		//System is predefined class
		//out is object of PrintStream
		//println() is method
		System.out.println();
		System.out.println();
	}
	

}
