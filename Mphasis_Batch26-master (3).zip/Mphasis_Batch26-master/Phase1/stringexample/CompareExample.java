package stringexample;

public class CompareExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="HEllo";
		String s1="hello";
		System.out.println(s.compareTo(s1)); 
		System.out.println(s.compareToIgnoreCase(s1));
	}

}

/*A-65, B-66
a-97, b=98
0-48
space-32*/


/*H=72
h=104
H-h=-32*/