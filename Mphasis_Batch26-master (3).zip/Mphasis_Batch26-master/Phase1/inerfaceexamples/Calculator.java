package inerfaceexamples;

/* interface is a collection of final type variables, declaration of methods and working is given by class*/
/* it is a contract for a class */
/* a class can use multiple interface */
/* interface contains private, static and default methods */
public interface Calculator {
	int addition(int num1, int num2);
	int subtraction(int num1, int num2);
}
