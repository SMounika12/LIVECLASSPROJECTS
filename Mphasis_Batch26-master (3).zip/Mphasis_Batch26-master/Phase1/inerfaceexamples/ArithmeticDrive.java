package inerfaceexamples;

public class ArithmeticDrive {

	public static void main(String[] args) {
		ArithmeticCalculator obj=new ArithmeticCalculator();
		System.out.println("Sum="+obj.addition(56, 45));
		System.out.println("Difference="+obj.subtraction(23, 15));

	}

}
